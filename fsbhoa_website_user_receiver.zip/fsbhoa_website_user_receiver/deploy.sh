#!/bin/bash
echo "Packaging Receiver plugin..."

cd ..

zip -r fsbhoa_website_user_receiver/fsbhoa_website_user_receiver.zip fsbhoa_website_user_receiver -x "*.git*" "*.DS_Store" "*debug.log" "*/build_release.sh" "*/*.zip"

echo "On PC, use this to pull the zip file:"
echo "   scp pi@testbed.fsbhoa.com:~/fsbhoa_website_user_receiver/fsbhoa_website_user_receiver.zip C:\\Users\\dkeen\\Downloads\\"
echo ""
echo "Done! Created: fsbhoa_website_user_receiver.zip"

